package models

const (
	FilePath     = "./big.txt"
	ChunkSize    = 64 * 1024 
	NumWorkers   = 5
	TopWordCount = 10
)
