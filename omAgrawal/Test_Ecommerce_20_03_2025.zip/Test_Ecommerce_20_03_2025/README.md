our Project is reading a Ecommerce transaction data 
and extracting information from the csv file and processing the data

the input is "ecommerce_transaction.csv" file
it should be in the same folder as the "main.exe file"

than we have to run "main.exe" file

the output will be of this format
The data of the file
Total revenue per product
most purchased product
Total revenue per customer
Total Revenue per category




