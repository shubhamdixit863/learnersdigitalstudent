package utils

var DisplayOptions = []string{
	"\n=== URL Shortener ===",
	"1. Shorten a URL",
	"2. Retrieve Original URL",
	"3. Cleanup Expired URLs",
	"4. Exit",
	"Choose an option (1-4): ",
}